--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.16 (Ubuntu 11.16-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE d29qkq0oiop71k;
--
-- Name: d29qkq0oiop71k; Type: DATABASE; Schema: -; Owner: uhytxisojtotui
--

CREATE DATABASE d29qkq0oiop71k WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE d29qkq0oiop71k OWNER TO uhytxisojtotui;

\connect d29qkq0oiop71k

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: uhytxisojtotui
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO uhytxisojtotui;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: uhytxisojtotui
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

--
-- Name: approved_users; Type: TABLE; Schema: public; Owner: uhytxisojtotui
--

CREATE TABLE public.approved_users (
    username character varying(100)
);


ALTER TABLE public.approved_users OWNER TO uhytxisojtotui;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: uhytxisojtotui
--

CREATE TABLE public.posts (
    post_name character varying(100),
    link character varying(100)
);


ALTER TABLE public.posts OWNER TO uhytxisojtotui;

--
-- Data for Name: approved_users; Type: TABLE DATA; Schema: public; Owner: uhytxisojtotui
--

COPY public.approved_users (username) FROM stdin;
\.
COPY public.approved_users (username) FROM '$$PATH$$/3932.dat';

--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: uhytxisojtotui
--

COPY public.posts (post_name, link) FROM stdin;
\.
COPY public.posts (post_name, link) FROM '$$PATH$$/3933.dat';

--
-- Name: DATABASE d29qkq0oiop71k; Type: ACL; Schema: -; Owner: uhytxisojtotui
--

REVOKE CONNECT,TEMPORARY ON DATABASE d29qkq0oiop71k FROM PUBLIC;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: uhytxisojtotui
--

REVOKE ALL ON SCHEMA public FROM postgres;
REVOKE ALL ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO uhytxisojtotui;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: LANGUAGE plpgsql; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON LANGUAGE plpgsql TO uhytxisojtotui;


--
-- PostgreSQL database dump complete
--

